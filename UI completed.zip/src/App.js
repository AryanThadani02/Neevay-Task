import './index.css';
import SearchResults from './SearchResults';

function App() {
  return (
    <SearchResults/>
  );
}

export default App;
